# Resumo da Esteira

Commit: `5c121fc1a74d8bf4ce5519e61d4a6efad1d58e15`

Execução: https://github.com/09780987/cp03-operacao-blackout-devsecops/actions/runs/41557834346

| Etapa | Resultado | Achados |
| --- | --- | --- |
| 1. Gitleaks | failure | 1 segredos |
| 2. Semgrep | skipped | indisponível achados; indisponível avisos de cobertura/operação |
| 3. Build e dependências | skipped | indisponível vulnerabilidades no npm audit |
| 4. Trivy fs e bundle | skipped | indisponível no projeto; indisponível no inventário parcial HIGH/CRITICAL |
| 5. Docker e GHCR | skipped | Sem publicação confirmada nesta execução |
| 6. Trivy image | skipped | indisponível HIGH/CRITICAL corrigíveis |
| 7. Homologação e ZAP | skipped | indisponível High; indisponível Medium |
| 8. Aprovação e produção | skipped | Registro de aprovação indisponível nos artifacts; deploy não confirmado |

Relatórios ausentes aparecem como indisponíveis. Etapas puladas não equivalem a resultado limpo.
