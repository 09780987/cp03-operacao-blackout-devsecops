# Deploy em produção

Provedor: Render

Plano: Free

Imagem: `ghcr.io/09780987/cp03-operacao-blackout-devsecops@sha256:f038e8bd6c53cab7bf1e5c3a301ed719af201778bf4f5b719a5fd734a53c2a55`

Commit: `5fc7e6f6abb3485e1f7d56398380b133640866df`

Aprovação: 09780987

Deploy concluído: 2026-11-03T01:15:37.143349Z

URL: https://operacao-blackout-rm565098-rm565963.onrender.com

Execução: https://github.com/09780987/cp03-operacao-blackout-devsecops/actions/runs/41557869924

Verificação: status live, digest aprovado, HTTP 200, página do Blackout e versão igual ao commit.
