# Docker Build e GHCR

Imagem: `ghcr.io/09780987/cp03-operacao-blackout-devsecops:5fc7e6f6abb3485e1f7d56398380b133640866df`

Digest: `sha256:f038e8bd6c53cab7bf1e5c3a301ed719af201778bf4f5b719a5fd734a53c2a55`

Execução: https://github.com/09780987/cp03-operacao-blackout-devsecops/actions/runs/41557869924
