# ZAP Scanning Report

ZAP by [Checkmarx](https://checkmarx.com/).


## Summary of Alerts

| Risk Level | Number of Alerts |
| --- | --- |
| High | 0 |
| Medium | 0 |
| Low | 2 |
| Informational | 2 |




## Insights

| Level | Reason | Site | Description | Statistic |
| --- | --- | --- | --- | --- |
| Low | Warning |  | ZAP warnings logged - see the zap.log file for details | 2    |
| Info | Informational | http://127.0.0.1:3000 | Percentage of responses with status code 2xx | 88 % |
| Info | Informational | http://127.0.0.1:3000 | Percentage of responses with status code 4xx | 11 % |
| Info | Informational | http://127.0.0.1:3000 | Percentage of endpoints with content type application/json | 14 % |
| Info | Informational | http://127.0.0.1:3000 | Percentage of endpoints with content type image/svg+xml | 14 % |
| Info | Informational | http://127.0.0.1:3000 | Percentage of endpoints with content type text/css | 14 % |
| Info | Informational | http://127.0.0.1:3000 | Percentage of endpoints with content type text/html | 14 % |
| Info | Informational | http://127.0.0.1:3000 | Percentage of endpoints with content type text/javascript | 28 % |
| Info | Informational | http://127.0.0.1:3000 | Percentage of endpoints with content type text/plain | 14 % |
| Info | Informational | http://127.0.0.1:3000 | Percentage of endpoints with method GET | 100 % |
| Info | Informational | http://127.0.0.1:3000 | Count of total endpoints | 7    |







## Alerts

| Name | Risk Level | Number of Instances |
| --- | --- | --- |
| Private IP Disclosure | Low | 1 |
| Timestamp Disclosure - Unix | Low | 1 |
| Modern Web Application | Informational | 2 |
| Non-Storable Content | Informational | Systemic |




## Alert Detail



### [ Private IP Disclosure ](https://www.zaproxy.org/docs/alerts/2/)



##### Low (Medium)

### Description

A private IP (such as 10.x.x.x, 172.x.x.x, 192.168.x.x) or an Amazon EC2 private hostname (for example, ip-10-0-56-78) has been found in the HTTP response body. This information might be helpful for further attacks targeting internal systems.

* URL: http://127.0.0.1:3000/blackout/assets/index-D5b49BWm.js
  * Node Name: `http://127.0.0.1:3000/blackout/assets/index-D5b49BWm.js`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `192.168.1.5`
  * Other Info: `192.168.1.5
192.168.1.5
192.168.1.5
192.168.1.42
192.168.1.5
192.168.1.42
192.168.1.10
192.168.1.5
192.168.1.7
192.168.1.5
192.168.1.42
192.168.1.20
192.168.1.5
10.0.2.15
10.0.0.1
10.0.2.15
10.0.2.30
10.0.2.15
10.0.0.5
10.0.2.30
10.0.2.15
10.0.0.1
10.0.2.50
10.0.0.10
10.0.2.30
10.0.0.5
10.0.2.15
10.0.2.30
10.0.2.99
10.0.2.15
10.0.0.1
172.16.10.20
172.16.10.5
172.16.10.5
172.16.10.30
172.16.10.5
172.16.10.5
172.16.10.5
172.16.10.40
172.16.10.5
172.16.10.20
172.16.10.5
172.16.10.20
172.16.10.99
172.16.10.20
172.16.10.5
172.16.10.50
172.16.10.5
172.16.10.40
192.168.50.10
192.168.50.1
192.168.50.1
192.168.50.10
192.168.50.1
192.168.50.10
192.168.50.1
192.168.50.20
192.168.50.10
192.168.50.1
192.168.50.1
192.168.50.30
10.0.0.50
10.0.0.10
10.0.0.50
10.0.0.10
10.0.0.50
10.0.0.10
10.0.0.60
10.0.0.50
10.0.0.50
10.0.0.50
192.168.1.42
`


Instances: 1

### Solution

Remove the private IP address from the HTTP response body. For comments, use JSP/ASP/PHP comment instead of HTML/JavaScript comment which can be seen by client browsers.

### Reference


* [ https://datatracker.ietf.org/doc/html/rfc1918 ](https://datatracker.ietf.org/doc/html/rfc1918)


#### CWE Id: [ 497 ](https://cwe.mitre.org/data/definitions/497.html)


#### WASC Id: 13

#### Source ID: 3

### [ Timestamp Disclosure - Unix ](https://www.zaproxy.org/docs/alerts/10096/)



##### Low (Low)

### Description

A timestamp was disclosed by the application/web server. - Unix

* URL: http://127.0.0.1:3000/blackout/assets/index-D5b49BWm.js
  * Node Name: `http://127.0.0.1:3000/blackout/assets/index-D5b49BWm.js`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `1831565813`
  * Other Info: `1831565813, which evaluates to: 2028-01-15 16:16:53.`


Instances: 1

### Solution

Manually confirm that the timestamp data is not sensitive, and that the data cannot be aggregated to disclose exploitable patterns.

### Reference


* [ https://cwe.mitre.org/data/definitions/200.html ](https://cwe.mitre.org/data/definitions/200.html)


#### CWE Id: [ 497 ](https://cwe.mitre.org/data/definitions/497.html)


#### WASC Id: 13

#### Source ID: 3

### [ Modern Web Application ](https://www.zaproxy.org/docs/alerts/10109/)



##### Informational (Medium)

### Description

The application appears to be a modern web application. If you need to explore it automatically then the Client Spider may well be more effective than the standard one.

* URL: http://127.0.0.1:3000
  * Node Name: `http://127.0.0.1:3000`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `<script type="module" src="/local-game.mjs"></script>`
  * Other Info: `No links have been found while there are scripts, which is an indication that this is a modern web application.`
* URL: http://127.0.0.1:3000/
  * Node Name: `http://127.0.0.1:3000/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `<script type="module" src="/local-game.mjs"></script>`
  * Other Info: `No links have been found while there are scripts, which is an indication that this is a modern web application.`


Instances: 2

### Solution

This is an informational alert and so no changes are required.

### Reference




#### Source ID: 3

### [ Non-Storable Content ](https://www.zaproxy.org/docs/alerts/10049/)



##### Informational (Medium)

### Description

The response contents are not storable by caching components such as proxy servers. If the response does not contain sensitive, personal or user-specific information, it may benefit from being stored and cached, to improve performance.

* URL: http://127.0.0.1:3000
  * Node Name: `http://127.0.0.1:3000`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://127.0.0.1:3000/
  * Node Name: `http://127.0.0.1:3000/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://127.0.0.1:3000/local-game.mjs
  * Node Name: `http://127.0.0.1:3000/local-game.mjs`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://127.0.0.1:3000/sitemap.xml
  * Node Name: `http://127.0.0.1:3000/sitemap.xml`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``

Instances: Systemic


### Solution

The content may be marked as storable by ensuring that the following conditions are satisfied:
The request method must be understood by the cache and defined as being cacheable ("GET", "HEAD", and "POST" are currently defined as cacheable)
The response status code must be understood by the cache (one of the 1XX, 2XX, 3XX, 4XX, or 5XX response classes are generally understood)
The "no-store" cache directive must not appear in the request or response header fields
For caching by "shared" caches such as "proxy" caches, the "private" response directive must not appear in the response
For caching by "shared" caches such as "proxy" caches, the "Authorization" header field must not appear in the request, unless the response explicitly allows it (using one of the "must-revalidate", "public", or "s-maxage" Cache-Control response directives)
In addition to the conditions above, at least one of the following conditions must also be satisfied by the response:
It must contain an "Expires" header field
It must contain a "max-age" response directive
For "shared" caches such as "proxy" caches, it must contain a "s-maxage" response directive
It must contain a "Cache Control Extension" that allows it to be cached
It must have a status code that is defined as cacheable by default (200, 203, 204, 206, 300, 301, 404, 405, 410, 414, 501).

### Reference


* [ https://datatracker.ietf.org/doc/html/rfc7234 ](https://datatracker.ietf.org/doc/html/rfc7234)
* [ https://datatracker.ietf.org/doc/html/rfc7231 ](https://datatracker.ietf.org/doc/html/rfc7231)
* [ https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html ](https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html)


#### CWE Id: [ 524 ](https://cwe.mitre.org/data/definitions/524.html)


#### WASC Id: 13

#### Source ID: 3


