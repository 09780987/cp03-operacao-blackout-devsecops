# Resumo da Esteira

Commit: `5fc7e6f6abb3485e1f7d56398380b133640866df`

Execução: https://github.com/09780987/cp03-operacao-blackout-devsecops/actions/runs/41557869924

| Etapa | Resultado | Achados |
| --- | --- | --- |
| 1. Gitleaks | success | 0 segredos |
| 2. Semgrep | success | 0 achados; 3 avisos de cobertura/operação |
| 3. Build e dependências | success | 0 vulnerabilidades no npm audit |
| 4. Trivy fs e bundle | success | 0 no projeto; 0 no inventário parcial HIGH/CRITICAL |
| 5. Docker e GHCR | success | Imagem e digest no relatório |
| 6. Trivy image | success | 0 HIGH/CRITICAL corrigíveis |
| 7. Homologação e ZAP | success | 0 High; 0 Medium |
| 8. Aprovação e produção | success | Aprovado por 09780987; consultar o relatório de produção |

Relatórios ausentes aparecem como indisponíveis. Etapas puladas não equivalem a resultado limpo.
